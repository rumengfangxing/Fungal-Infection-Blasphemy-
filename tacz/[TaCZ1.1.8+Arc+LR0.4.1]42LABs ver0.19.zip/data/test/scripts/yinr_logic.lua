local M = {}

M.shootCounter = 0
M.timerTaskId = nil
M.reloadTaskId = nil

function M.shoot(api)
    -- 增加计数器（这是关键，必须在最前面）
    M.shootCounter = M.shootCounter + 1
    local myShootId = M.shootCounter
    
    -- 立即停止所有任务
    if M.reloadTaskId then
        api:cancelAsyncTask(M.reloadTaskId)
        M.reloadTaskId = nil
    end
    if M.timerTaskId then
        api:cancelAsyncTask(M.timerTaskId)
        M.timerTaskId = nil
    end
    
    -- 射击
    api:shootOnce(api:isShootingNeedConsumeAmmo())
    
    -- 只有在弹夹未满时才启动5秒延迟计时器
    if api:getAmmoAmount() < api:getMaxAmmoCount() then
        local countdown = 0
        M.timerTaskId = api:safeAsyncTask(
            function()
                -- 检查是否有新射击（这里是关键）
                if M.shootCounter ~= myShootId then
                    return false  -- 有新射击，停止当前计时器
                end
                
                countdown = countdown + 100
                
                -- 5秒未到，继续计时
                if countdown < 4000   then
                    return true
                end

                
                
                -- 5秒到了，开始补弹
                M.timerTaskId = nil
                if api:getAmmoAmount() < api:getMaxAmmoCount() then
                    M.reloadTaskId = api:safeAsyncTask(
                        function()
                            -- 补弹期间也要检查新射击
                            if M.shootCounter ~= myShootId then
                                return false  -- 有新射击，停止补弹
                            end
                            
                            if api:getAmmoAmount() >= api:getMaxAmmoCount() then
                                return false  -- 弹夹满了，停止补弹
                            end
                            
                            api:putAmmoInMagazine(1)
                            return true
                        end,
                        0,   -- 立即开始
                        350, -- 每500ms一发
                        -1   -- 无限次数
                    )
                end
                
                return false  -- 计时器任务完成
            end,
            0,   -- 立即开始
            100, -- 每100ms检查一次
            -1   -- 无限次数
        )
    end
end

return M
