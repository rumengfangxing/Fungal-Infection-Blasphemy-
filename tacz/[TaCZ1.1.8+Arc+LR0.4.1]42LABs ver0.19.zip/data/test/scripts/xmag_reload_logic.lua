local M = {}

-- 射击计数器，用于追踪最新的射击事件
M.shootCounter = 0
-- 补弹任务ID
M.reloadTaskId = nil

function M.shoot(api)
    -- 增加计数器（这是关键，必须在最前面）
    M.shootCounter = M.shootCounter + 1
    local myShootId = M.shootCounter
    
    -- 立即停止所有正在进行的补弹任务
    if M.reloadTaskId then
        api:cancelAsyncTask(M.reloadTaskId)
        M.reloadTaskId = nil
    end
    
    -- 执行射击
    api:shootOnce(api:isShootingNeedConsumeAmmo())
    
    -- 检查是否需要补弹：当弹匣未满时启动延长补弹
    if api:getAmmoAmount() < api:getMaxAmmoCount() then
        M.reloadTaskId = api:safeAsyncTask(
            function()
                -- 检查是否有新射击，如果有则停止当前补弹任务
                if M.shootCounter ~= myShootId then
                    return false  -- 有新射击，停止当前补弹
                end
                
                -- 检查弹匣是否已满，如果满了则停止补弹
                if api:getAmmoAmount() >= api:getMaxAmmoCount() then
                    return false  -- 弹夹满了，停止补弹
                end
                
                -- 补充一发子弹到弹匣
                api:putAmmoInMagazine(1)
                
                -- 继续补弹，直到弹匣满或发生新射击
                return true
            end,
            0,    -- 立即开始
            350,  -- 每350毫秒补充一发子弹
            -1    -- 无限次数，直到条件不满足
        )
    end
end

return M
